import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panier-root',
  templateUrl: './panier-root.component.html',
  styleUrls: ['./panier-root.component.css']
})
export class PanierRootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
