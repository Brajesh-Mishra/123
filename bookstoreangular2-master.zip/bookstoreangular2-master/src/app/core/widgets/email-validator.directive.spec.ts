import { EmailValidatorDirective } from './email-validator.directive';

describe('EmailValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new EmailValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
