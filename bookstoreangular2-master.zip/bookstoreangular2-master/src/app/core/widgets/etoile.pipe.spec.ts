import { EtoilePipe } from './etoile.pipe';

describe('EtoilePipe', () => {
  it('create an instance', () => {
    const pipe = new EtoilePipe();
    expect(pipe).toBeTruthy();
  });
});
