import { ZipcodeValidatorDirective } from './zipcode-validator.directive';

describe('ZipcodeValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new ZipcodeValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
